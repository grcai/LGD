These are three datasets for the following paper. 

Ruijia Li, Xiaofei Yang, Xiaolong Qin, William Zhu, Local gap density for clustering high-dimensional data.


## Datasets ###############################################################
jaffe [1]; COIL20 [2]; TDT2 [3]

## References #############################################################
[1] M. Lyons, S. Akamatsu, M. Kamachi, J. Gyoba, Coding facial expressions
with gabor wavelets, in: Proc. of the 3rd IEEE International Conference on Automatic Face and Gesture Recognition, 1998, pp. 200�C205.
[2] S. A. Nene, S. K. Nayar, H. Murase, et al., Columbia object image library (COIL-20).
[3] D. Cai, X. He, J. Han, Document clustering using locality preserving indexing, IEEE Trans. Knowl. Data Eng. 17 (12) (2005) 1624�C1637.