These are two datasets for the following paper. 

Ruijia Li, Xiaofei Yang, Xiaolong Qin, William Zhu, Local gap density for clustering high-dimensional data.


## Datasets ##################################################################
breast [1]; USPS [2].  


## References ################################################################
[1] K. P. Bennett, O. L. Mangasarian, Robust linear programming discrimi-
nation of two linearly inseparable sets, Optim. Method Softw. 1 (1) (1992)
23�C34.
[2] J. J. Hull, A database for handwritten text recognition research, IEEE
Trans. Pattern Anal. Mach. Intell. 16 (5) (1994) 550�C554.
