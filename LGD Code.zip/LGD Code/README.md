This is a MATLAB implementation of the algorithm LGD presented in the following paper. 

Ruijia Li, Xiaofei Yang, Xiaolong Qin, William Zhu, Local gap density for clustering high-dimensional data.

main1.m is the code for testing the algorithm LGD on the real-world datasets.
main2.m is the code for testing the algorithm LGD on the synthetic datasets.
Please download the real-world datasets at https://github.com/grcai.
