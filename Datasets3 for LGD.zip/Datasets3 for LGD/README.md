These are three datasets for the following paper. 

Ruijia Li, Xiaofei Yang, Xiaolong Qin, William Zhu, Local gap density for clustering high-dimensional data.


## Datasets ###############################################################
ecoli [1]; arcene [2]; gisette [2].


## References #############################################################
[1] D. Dheeru, E. Karra Taniskidou, UCI machine learning repository (2017).
[2] I. Guyon, S. Gunn, A. Ben-Hur, G. Dror, Result analysis of the NIPS 2003 feature selection challenge, in: Proc. of the 17th Annual Conference on Neural Information Processing Systems, 2004, pp. 545�C552.